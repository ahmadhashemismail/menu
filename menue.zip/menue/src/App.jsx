import { BrowserRouter, Routes, Route, Navigate, Link } from 'react-router-dom'
import Menu from './src/pages/menu'
import Admin from './src/pages/admin'



function App() {
  return (
    <BrowserRouter>
      <nav>
        <Link to="/menu">Menu</Link>
        {' | '}
        <Link to="/login">Admin Login</Link>
        <Link to="/admin">Admin</Link>

      </nav>

      <Routes>
        <Route path="/admin" element={<Admin />} />
        <Route path="/" element={<Navigate to="/menu" replace />} />
        <Route path="/menu" element={<Menu />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App