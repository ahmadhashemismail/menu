import { useState, useEffect } from 'react'

function Admin() {
  const [food, setFood] = useState([])
  const [drinks, setDrinks] = useState([])
  const [category, setCategory] = useState('food') // 'food' or 'drink'
  const [form, setForm] = useState({ item_name: '', image: '' })
  const [editingId, setEditingId] = useState(null)

  const fetchAll = async () => {
    const [foodRes, drinkRes] = await Promise.all([
      fetch('/api/food'),
      fetch('/api/drink'),
    ])
    setFood(await foodRes.json())
    setDrinks(await drinkRes.json())
  }

  useEffect(() => {
    fetchAll()
  }, [])

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const url = editingId ? `/api/${category}/${editingId}` : `/api/${category}`
    const method = editingId ? 'PUT' : 'POST'

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error('Request failed')

      setForm({ item_name: '', image: '' })
      setEditingId(null)
      fetchAll()
    } catch (err) {
      console.error(err)
      alert('Something went wrong saving the item')
    }
  }

  const handleEdit = (item, cat) => {
    setCategory(cat)
    setForm({ item_name: item.item_name, image: item.image })
    setEditingId(item.id)
  }

  const handleDelete = async (id, cat) => {
    if (!confirm('Delete this item?')) return
    try {
      await fetch(`/api/${cat}/${id}`, { method: 'DELETE' })
      fetchAll()
    } catch (err) {
      console.error(err)
      alert('Something went wrong deleting the item')
    }
  }

  const renderList = (items, cat) => (
    <div className="admin-grid">
      {items.map((item) => (
        <div key={item.id} className="admin-item">
          <img src={item.image} alt={item.item_name} width="100" />
          <p>{item.item_name}</p>
          <button onClick={() => handleEdit(item, cat)}>Edit</button>
          <button onClick={() => handleDelete(item.id, cat)}>Delete</button>
        </div>
      ))}
    </div>
  )

  return (
    <div>
      <h1>Admin — Manage Menu</h1>

      <form onSubmit={handleSubmit}>
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="food">Food</option>
          <option value="drink">Drink</option>
        </select>

        <input
          type="text"
          name="item_name"
          placeholder="Item name"
          value={form.item_name}
          onChange={handleChange}
          required
        />

        <input
          type="text"
          name="image"
          placeholder="Image URL/path"
          value={form.image}
          onChange={handleChange}
        />

        <button type="submit">{editingId ? 'Update' : 'Add'} Item</button>
        {editingId && (
          <button
            type="button"
            onClick={() => {
              setEditingId(null)
              setForm({ item_name: '', image: '' })
            }}
          >
            Cancel
          </button>
        )}
      </form>

      <h2>Food Items</h2>
      {renderList(food, 'food')}

      <h2>Drink Items</h2>
      {renderList(drinks, 'drink')}
    </div>
  )
}

export default Admin